 import { useState, useEffect } from "react";
 import { supabase } from "@/integrations/supabase/client";
 import { useAuth } from "./useAuth";
 
 export interface Profile {
   id: string;
   email: string;
   full_name: string;
   age: number | null;
   region: string;
   languages: string[];
   games_played: string[];
   games_looking_for: string[];
   discord_username: string | null;
   skill_level: string | null;
   avatar_url: string | null;
   created_at: string;
   updated_at: string;
 }
 
 export const useProfile = () => {
   const { user } = useAuth();
   const [profile, setProfile] = useState<Profile | null>(null);
   const [loading, setLoading] = useState(true);
 
   useEffect(() => {
     if (!user) {
       setProfile(null);
       setLoading(false);
       return;
     }
 
     const fetchProfile = async () => {
       setLoading(true);
       const { data, error } = await supabase
         .from("profiles")
         .select("*")
         .eq("id", user.id)
         .maybeSingle();
 
       if (error) {
         console.error("Error fetching profile:", error);
       } else {
         setProfile(data);
       }
       setLoading(false);
     };
 
     fetchProfile();
   }, [user]);
 
   const updateProfile = async (updates: Partial<Profile>) => {
     if (!user) return { error: new Error("Not authenticated") };
 
     const { error } = await supabase
       .from("profiles")
       .update(updates)
       .eq("id", user.id);
 
     if (!error && profile) {
       setProfile({ ...profile, ...updates });
     }
 
     return { error };
   };
 
   return { profile, loading, updateProfile };
 };