import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, GraduationCap, Gamepad2, Heart, Target, Users } from "lucide-react";

const team = [
  {
    name: "Mihajlo Djordjevic",
    role: "Co-Founder",
    bio: "Passionate gamer and developer who understands the struggle of finding good teammates.",
  },
  {
    name: "Ilija Djordjevic",
    role: "Co-Founder",
    bio: "Game enthusiast focused on creating seamless user experiences for the gaming community.",
  },
  {
    name: "Dusan Mitrovic",
    role: "Co-Founder",
    bio: "Competitive gamer who brings firsthand experience of what teammates need to succeed.",
  },
];

const values = [
  {
    icon: Users,
    title: "Community First",
    description: "We believe gaming is better together. Every decision we make puts our community first.",
  },
  {
    icon: Target,
    title: "Quality Matches",
    description: "We're obsessed with finding you the perfect teammate, not just any teammate.",
  },
  {
    icon: Heart,
    title: "Player Safety",
    description: "A toxic-free environment where every gamer can feel safe and respected.",
  },
];

const About = () => {
  return (
    <div className="min-h-screen py-16">
      <div className="container relative px-4">
        {/* Hero */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <div className="inline-flex items-center gap-2 bg-primary/8 border border-primary/15 rounded-full px-5 py-2.5 mb-8">
            <GraduationCap className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Built by students, for gamers</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 tracking-tight">
            About Team<span className="text-gradient">8</span>
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
            We are students from Serbia studying at the Faculty of Organizational Sciences (FON). As passionate gamers, we experienced how frustrating it is to find reliable teammates online. Team8 was created to solve that problem.
          </p>
        </div>

        {/* Story */}
        <div className="max-w-3xl mx-auto mb-20">
          <div className="bg-card border border-border rounded-2xl p-8 md:p-10">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Gamepad2 className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Our Story</h2>
            </div>
            <div className="space-y-4 text-muted-foreground leading-relaxed text-sm">
              <p>
                It all started during a late-night gaming session. We were trying to find teammates for
                a competitive match, but every random player we got was either toxic, spoke a different
                language, or was playing from a different region with 200ms ping.
              </p>
              <p>
                After countless frustrating experiences, we realized this wasn't just our problem — it
                was a problem for millions of gamers worldwide. The existing solutions were either too
                complicated, too expensive, or simply didn't work well enough.
              </p>
              <p>
                So we decided to build something better. As students at the Faculty of Organizational
                Sciences (FON) in Belgrade, Serbia, we combined our technical skills with our passion
                for gaming to create Team8.
              </p>
              <p className="text-foreground font-medium text-base">
                Our mission is simple: connect gamers faster and better than ever before.
              </p>
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="max-w-4xl mx-auto mb-20">
          <h2 className="text-2xl font-bold text-foreground text-center mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {values.map((value, index) => (
              <div key={index} className="bg-card border border-border rounded-2xl p-7 text-center card-hover">
                <div className="w-12 h-12 rounded-xl bg-primary/8 flex items-center justify-center mx-auto mb-5">
                  <value.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-bold text-foreground mb-2">{value.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Team */}
        <div className="max-w-4xl mx-auto mb-20">
          <h2 className="text-2xl font-bold text-foreground text-center mb-12">Meet the Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {team.map((member, index) => (
              <div key={index} className="bg-card border border-border rounded-2xl p-7 text-center card-hover">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-5">
                  <span className="text-2xl font-bold text-gradient">
                    {member.name.charAt(0)}
                  </span>
                </div>
                <h3 className="font-bold text-foreground mb-1">{member.name}</h3>
                <p className="text-primary text-xs font-semibold mb-3 uppercase tracking-wider">{member.role}</p>
                <p className="text-muted-foreground text-sm leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground text-sm">
              Students at the{" "}
              <span className="text-foreground font-medium">
                Faculty of Organizational Sciences (FON)
              </span>
              , University of Belgrade, Serbia
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="max-w-3xl mx-auto text-center">
          <div className="bg-card border border-border rounded-2xl p-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Join Our Growing Community
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Be part of something special. Help us build the future of gaming connections.
            </p>
            <Link to="/register">
              <Button variant="hero" size="xl">
                Get Started Today
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
