import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import PlayerCard from "@/components/ui/PlayerCard";
import { Search, Filter, X, Users } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

const games = [
  "Valorant", "CS2", "League of Legends", "Fortnite",
  "Apex Legends", "Overwatch 2", "Dota 2", "Rocket League",
  "PUBG", "Rainbow Six Siege",
];

const regions = [
  "North America", "Europe", "Asia", "South America",
  "Oceania", "Middle East", "Africa",
];

const languages = [
  "English", "Spanish", "Portuguese", "German", "French",
  "Russian", "Chinese", "Japanese", "Korean", "Arabic", "Serbian",
];

const skillLevels = ["Beginner", "Casual", "Intermediate", "Advanced", "Pro"];

// Demo players that always show
const demoPlayers = [
  {
    id: "demo-1",
    full_name: "Alex",
    games_played: ["Valorant"],
    games_looking_for: ["Valorant"],
    region: "Europe",
    languages: ["English"],
    age: 22,
    avatar_url: null,
    rank: "Diamond",
    online: true,
  },
  {
    id: "demo-2",
    full_name: "Marko",
    games_played: ["CS2"],
    games_looking_for: ["CS2"],
    region: "Europe",
    languages: ["Serbian", "English"],
    age: 24,
    avatar_url: null,
    rank: "Global Elite",
    online: true,
  },
  {
    id: "demo-3",
    full_name: "Lina",
    games_played: ["League of Legends"],
    games_looking_for: ["League of Legends"],
    region: "Europe",
    languages: ["English", "German"],
    age: 20,
    avatar_url: null,
    rank: "Platinum",
    online: false,
  },
  {
    id: "demo-4",
    full_name: "Nikola",
    games_played: ["Fortnite"],
    games_looking_for: ["Fortnite"],
    region: "Europe",
    languages: ["Serbian", "English"],
    age: 19,
    avatar_url: null,
    rank: "Champion",
    online: true,
  },
  {
    id: "demo-5",
    full_name: "David",
    games_played: ["Apex Legends"],
    games_looking_for: ["Apex Legends"],
    region: "North America",
    languages: ["English"],
    age: 26,
    avatar_url: null,
    rank: "Master",
    online: false,
  },
  {
    id: "demo-6",
    full_name: "Sara",
    games_played: ["Valorant"],
    games_looking_for: ["Valorant"],
    region: "Europe",
    languages: ["English"],
    age: 21,
    avatar_url: null,
    rank: "Immortal",
    online: true,
  },
];

interface PlayerProfile {
  id: string;
  full_name: string;
  games_played: string[];
  games_looking_for: string[];
  region: string;
  languages: string[];
  age: number | null;
  avatar_url: string | null;
  rank?: string;
  online?: boolean;
}

const FindTeammate = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [players, setPlayers] = useState<PlayerProfile[]>([]);
  const [isLoadingPlayers, setIsLoadingPlayers] = useState(true);

  useEffect(() => {
    const fetchPlayers = async () => {
      setIsLoadingPlayers(true);
      const { data, error } = await supabase
        .from("profiles")
        .select("id, full_name, games_played, games_looking_for, region, languages, age, avatar_url")
        .neq("id", user?.id || "")
        .limit(50);

      if (error) {
        console.error("Error fetching players:", error);
        toast.error("Failed to load players");
        setPlayers(demoPlayers);
      } else {
        // Merge demo players with real players, avoiding duplicates
        const realPlayers = (data || []) as PlayerProfile[];
        const allPlayers = [...demoPlayers, ...realPlayers.filter(p => !demoPlayers.some(d => d.full_name === p.full_name))];
        setPlayers(allPlayers);
      }
      setIsLoadingPlayers(false);
    };

    fetchPlayers();
  }, [user?.id]);

  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGame, setSelectedGame] = useState<string>("");
  const [selectedRegion, setSelectedRegion] = useState<string>("");
  const [selectedLanguage, setSelectedLanguage] = useState<string>("");
  const [selectedSkill, setSelectedSkill] = useState<string>("");
  const [ageMin, setAgeMin] = useState("");
  const [ageMax, setAgeMax] = useState("");

  const filteredPlayers = players.filter((player) => {
    if (selectedGame && !player.games_looking_for.includes(selectedGame)) return false;
    if (selectedRegion && player.region !== selectedRegion) return false;
    if (selectedLanguage && !player.languages.includes(selectedLanguage)) return false;
    if (ageMin && (player.age || 0) < parseInt(ageMin)) return false;
    if (ageMax && (player.age || 0) > parseInt(ageMax)) return false;
    if (searchQuery && !player.full_name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const clearFilters = () => {
    setSelectedGame("");
    setSelectedRegion("");
    setSelectedLanguage("");
    setSelectedSkill("");
    setAgeMin("");
    setAgeMax("");
    setSearchQuery("");
  };

  const handleContact = (playerId: string, playerName: string) => {
    if (!user) {
      toast.info("Please create an account to message teammates", {
        action: {
          label: "Sign Up",
          onClick: () => navigate("/register"),
        },
      });
      return;
    }

    // Navigate to chat with demo player
    if (playerId.startsWith("demo-")) {
      navigate(`/chat?player=${playerName}`);
      return;
    }

    toast.success(`Contact request sent to ${playerName}!`);
  };

  const hasActiveFilters = selectedGame || selectedRegion || selectedLanguage || selectedSkill || ageMin || ageMax;

  return (
    <div className="min-h-screen py-16">
      <div className="container px-4">
        {/* Header */}
        <div className="max-w-4xl mx-auto text-center mb-14">
          <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-4 tracking-tight">
            Find Your Perfect Teammate
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Search through thousands of gamers to find players who match your preferences
          </p>
        </div>

        {/* Filter Panel */}
        <div className="max-w-6xl mx-auto mb-10">
          <div className="bg-card border border-border rounded-2xl p-5">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search Input */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by username..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-11 bg-secondary border-0"
                />
              </div>

              {/* Quick Filters */}
              <div className="flex gap-3 flex-wrap">
                <Select value={selectedGame} onValueChange={setSelectedGame}>
                  <SelectTrigger className="w-[160px] h-11 bg-secondary border-0">
                    <SelectValue placeholder="Game" />
                  </SelectTrigger>
                  <SelectContent>
                    {games.map((game) => (
                      <SelectItem key={game} value={game}>{game}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger className="w-[160px] h-11 bg-secondary border-0">
                    <SelectValue placeholder="Region" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map((region) => (
                      <SelectItem key={region} value={region}>{region}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  variant={showFilters ? "default" : "outline"}
                  onClick={() => setShowFilters(!showFilters)}
                  className="h-11"
                >
                  <Filter className="w-4 h-4" />
                  Filters
                </Button>

                {hasActiveFilters && (
                  <Button variant="ghost" onClick={clearFilters} className="h-11 text-muted-foreground">
                    <X className="w-4 h-4" />
                    Clear
                  </Button>
                )}
              </div>
            </div>

            {/* Extended Filters */}
            {showFilters && (
              <div className="mt-4 pt-4 border-t border-border animate-fade-in">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Language</Label>
                    <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                      <SelectTrigger className="bg-secondary border-0">
                        <SelectValue placeholder="Any language" />
                      </SelectTrigger>
                      <SelectContent>
                        {languages.map((lang) => (
                          <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Skill Level</Label>
                    <Select value={selectedSkill} onValueChange={setSelectedSkill}>
                      <SelectTrigger className="bg-secondary border-0">
                        <SelectValue placeholder="Any skill" />
                      </SelectTrigger>
                      <SelectContent>
                        {skillLevels.map((skill) => (
                          <SelectItem key={skill} value={skill}>{skill}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Age Range</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Min"
                        type="number"
                        value={ageMin}
                        onChange={(e) => setAgeMin(e.target.value)}
                        className="bg-secondary border-0"
                      />
                      <Input
                        placeholder="Max"
                        type="number"
                        value={ageMax}
                        onChange={(e) => setAgeMax(e.target.value)}
                        className="bg-secondary border-0"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Results Count */}
        <div className="max-w-6xl mx-auto mb-6 flex items-center gap-2">
          <Users className="w-4 h-4 text-muted-foreground" />
          <p className="text-muted-foreground text-sm">
            <span className="text-primary font-semibold">{filteredPlayers.length}</span> players found
            {hasActiveFilters && " matching your filters"}
          </p>
        </div>

        {/* Player Grid */}
        <div className="max-w-6xl mx-auto">
          {isLoadingPlayers ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-card border border-border rounded-2xl p-6 animate-pulse">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-xl bg-secondary" />
                    <div className="flex-1">
                      <div className="h-4 bg-secondary rounded w-28 mb-3" />
                      <div className="h-3 bg-secondary rounded w-40" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredPlayers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPlayers.map((player) => (
                <PlayerCard
                  key={player.id}
                  name={player.full_name}
                  games={player.games_looking_for}
                  region={player.region}
                  languages={player.languages}
                  age={player.age || 0}
                  avatar={player.avatar_url || undefined}
                  rank={player.rank}
                  online={player.online}
                  disabled={!user}
                  onContact={() => handleContact(player.id, player.full_name)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-24">
              <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-6">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">No players found</h3>
              <p className="text-muted-foreground mb-6 text-sm">
                Try adjusting your filters to see more results
              </p>
              <Button variant="outline" onClick={clearFilters}>
                Clear All Filters
              </Button>
            </div>
          )}
        </div>

        {/* Login CTA */}
        {!user && (
          <div className="max-w-6xl mx-auto mt-14">
            <div className="bg-primary/5 border border-primary/10 rounded-2xl p-10 text-center">
              <h3 className="text-xl font-bold text-foreground mb-3">
                Want to contact these players?
              </h3>
              <p className="text-muted-foreground mb-6">
                Create a free account to start connecting with teammates
              </p>
              <Button variant="hero" size="lg" onClick={() => navigate("/register")}>
                Create Free Account
                <Users className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FindTeammate;
