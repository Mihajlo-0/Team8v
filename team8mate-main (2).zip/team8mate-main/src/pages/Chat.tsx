import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Search, User, Gamepad2 } from "lucide-react";

// Demo conversations matching demo players
const demoConversations = [
  {
    id: "alex",
    name: "Alex",
    game: "Valorant",
    rank: "Diamond",
    lastMessage: "Hey, looking for a ranked teammate?",
    time: "Just now",
    unread: 1,
    online: true,
  },
  {
    id: "marko",
    name: "Marko",
    game: "CS2",
    rank: "Global Elite",
    lastMessage: "GG! That was a great match",
    time: "5 min ago",
    unread: 0,
    online: true,
  },
  {
    id: "sara",
    name: "Sara",
    game: "Valorant",
    rank: "Immortal",
    lastMessage: "Want to duo queue tonight?",
    time: "1 hour ago",
    unread: 2,
    online: true,
  },
  {
    id: "lina",
    name: "Lina",
    game: "League of Legends",
    rank: "Platinum",
    lastMessage: "I main support, looking for ADC",
    time: "Yesterday",
    unread: 0,
    online: false,
  },
];

const demoMessagesByPlayer: Record<string, Array<{ id: number; sender: string; message: string; time: string; isMe: boolean }>> = {
  Alex: [
    { id: 1, sender: "Alex", message: "Hey, looking for a ranked teammate?", time: "10:30 AM", isMe: false },
    { id: 2, sender: "Me", message: "Yes, what rank are you?", time: "10:31 AM", isMe: true },
    { id: 3, sender: "Alex", message: "Diamond 2, I usually play evenings. EU server.", time: "10:32 AM", isMe: false },
    { id: 4, sender: "Me", message: "Nice! I'm Diamond 1. What agents do you play?", time: "10:33 AM", isMe: true },
    { id: 5, sender: "Alex", message: "Mainly Jett and Reyna. I like aggressive plays but I can adapt.", time: "10:34 AM", isMe: false },
    { id: 6, sender: "Me", message: "Perfect, I play Killjoy and Omen. We'd be a good combo!", time: "10:35 AM", isMe: true },
    { id: 7, sender: "Alex", message: "Let's run some games tonight then! 🎮", time: "10:36 AM", isMe: false },
  ],
  Marko: [
    { id: 1, sender: "Marko", message: "Yo! Saw you play CS2, need a fifth for our stack?", time: "9:00 AM", isMe: false },
    { id: 2, sender: "Me", message: "Hey! Yeah I'm looking for a regular team. What's your rank?", time: "9:02 AM", isMe: true },
    { id: 3, sender: "Marko", message: "Global Elite. We play Faceit Level 10 mostly.", time: "9:03 AM", isMe: false },
    { id: 4, sender: "Me", message: "Sounds great, I'm Supreme. When do you guys usually play?", time: "9:05 AM", isMe: true },
    { id: 5, sender: "Marko", message: "GG! That was a great match", time: "9:30 AM", isMe: false },
  ],
  Sara: [
    { id: 1, sender: "Sara", message: "Hi! I saw we both play Valorant in EU 🇪🇺", time: "8:00 PM", isMe: false },
    { id: 2, sender: "Me", message: "Hey Sara! Yes! What's your rank?", time: "8:02 PM", isMe: true },
    { id: 3, sender: "Sara", message: "Immortal 1, I play Sage and Viper mostly.", time: "8:03 PM", isMe: false },
    { id: 4, sender: "Me", message: "Wow nice! I'd love to team up", time: "8:04 PM", isMe: true },
    { id: 5, sender: "Sara", message: "Want to duo queue tonight?", time: "8:05 PM", isMe: false },
  ],
  Lina: [
    { id: 1, sender: "Lina", message: "Hey! Looking for an ADC to duo with in ranked", time: "Yesterday", isMe: false },
    { id: 2, sender: "Me", message: "Hi! What rank are you?", time: "Yesterday", isMe: true },
    { id: 3, sender: "Lina", message: "I main support, looking for ADC", time: "Yesterday", isMe: false },
  ],
};

const Chat = () => {
  const [searchParams] = useSearchParams();
  const playerParam = searchParams.get("player");

  const [selectedChat, setSelectedChat] = useState(demoConversations[0]);
  const [message, setMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [messages, setMessages] = useState(demoMessagesByPlayer["Alex"] || []);

  // If navigated from player card, select that conversation
  useEffect(() => {
    if (playerParam) {
      const conv = demoConversations.find(c => c.name === playerParam);
      if (conv) {
        setSelectedChat(conv);
        setMessages(demoMessagesByPlayer[playerParam] || []);
      }
    }
  }, [playerParam]);

  const handleSelectChat = (conversation: typeof demoConversations[0]) => {
    setSelectedChat(conversation);
    setMessages(demoMessagesByPlayer[conversation.name] || []);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    const newMsg = {
      id: messages.length + 1,
      sender: "Me",
      message: message.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
    };
    setMessages(prev => [...prev, newMsg]);
    setMessage("");

    // Simulate reply after 1.5s
    setTimeout(() => {
      const replies = [
        "Sounds good! Let's do it 🎮",
        "I'm down for that!",
        "Nice, let me know when you're ready",
        "Perfect, adding you now!",
        "Let's queue up! 🔥",
      ];
      const reply = {
        id: messages.length + 2,
        sender: selectedChat.name,
        message: replies[Math.floor(Math.random() * replies.length)],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isMe: false,
      };
      setMessages(prev => [...prev, reply]);
    }, 1500);
  };

  const filteredConversations = demoConversations.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-4rem)] flex">
      {/* Sidebar */}
      <div className="w-80 border-r border-border bg-card flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <h2 className="font-bold text-foreground mb-3">Messages</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-secondary border-0 h-9 text-sm"
            />
          </div>
        </div>

        {/* Conversations */}
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {filteredConversations.map((conversation) => (
              <button
                key={conversation.id}
                onClick={() => handleSelectChat(conversation)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200 ${
                  selectedChat.id === conversation.id
                    ? "bg-primary/8 border border-primary/15"
                    : "hover:bg-secondary border border-transparent"
                }`}
              >
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  <div className="w-11 h-11 rounded-xl bg-secondary flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">
                      {conversation.name.charAt(0)}
                    </span>
                  </div>
                  {conversation.online && (
                    <div className="absolute -bottom-0.5 -right-0.5 online-dot border-2 border-card w-2.5 h-2.5" />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-foreground text-sm truncate">
                      {conversation.name}
                    </span>
                    <span className="text-[10px] text-muted-foreground">
                      {conversation.time}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <Gamepad2 className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    <span className="text-xs text-muted-foreground">{conversation.game} · {conversation.rank}</span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate mt-0.5">
                    {conversation.lastMessage}
                  </p>
                </div>

                {/* Unread */}
                {conversation.unread > 0 && (
                  <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <span className="text-[10px] font-bold text-primary-foreground">
                      {conversation.unread}
                    </span>
                  </div>
                )}
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        {/* Chat Header */}
        <div className="h-16 border-b border-border flex items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                <span className="font-bold text-primary text-sm">
                  {selectedChat.name.charAt(0)}
                </span>
              </div>
              {selectedChat.online && (
                <div className="absolute -bottom-0.5 -right-0.5 online-dot border-2 border-background w-2.5 h-2.5" />
              )}
            </div>
            <div>
              <h3 className="font-semibold text-foreground text-sm">{selectedChat.name}</h3>
              <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Gamepad2 className="w-3 h-3" />
                {selectedChat.game} · {selectedChat.rank}
                {selectedChat.online && <span className="text-[hsl(var(--online))]"> · Online</span>}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="rounded-xl">
            <User className="w-4 h-4" />
          </Button>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-6">
          <div className="space-y-4 max-w-2xl mx-auto">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.isMe ? "justify-end" : "justify-start"} animate-slide-up`}
              >
                <div className="flex items-end gap-2">
                  {!msg.isMe && (
                    <div className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0 mb-1">
                      <span className="text-xs font-bold text-primary">{msg.sender.charAt(0)}</span>
                    </div>
                  )}
                  <div
                    className={`max-w-[320px] rounded-2xl px-4 py-2.5 ${
                      msg.isMe
                        ? "bg-primary text-primary-foreground rounded-br-lg"
                        : "bg-card border border-border rounded-bl-lg"
                    }`}
                  >
                    <p className={`text-sm ${msg.isMe ? "text-primary-foreground" : "text-foreground"}`}>
                      {msg.message}
                    </p>
                    <p className={`text-[10px] mt-1 ${
                      msg.isMe ? "text-primary-foreground/60" : "text-muted-foreground"
                    }`}>
                      {msg.time}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Message Input */}
        <div className="p-4 border-t border-border">
          <form onSubmit={handleSendMessage} className="max-w-2xl mx-auto flex gap-3">
            <Input
              placeholder="Type a message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 h-11 bg-card border-0 rounded-xl"
            />
            <Button type="submit" size="lg" className="px-5 rounded-xl h-11">
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Chat;
