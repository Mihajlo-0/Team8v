 import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Gamepad2, Mail, Lock, User, Calendar, ArrowRight, Globe, MessageCircle } from "lucide-react";
 import { toast } from "sonner";
 import { useAuth } from "@/hooks/useAuth";

const games = [
  "Valorant",
  "CS2",
  "League of Legends",
  "Fortnite",
  "Apex Legends",
  "Overwatch 2",
  "Dota 2",
  "Rocket League",
  "PUBG",
  "Rainbow Six Siege",
];

const regions = [
  "North America",
  "Europe",
  "Asia",
  "South America",
  "Oceania",
  "Middle East",
  "Africa",
];

const languages = [
  "English",
  "Spanish",
  "Portuguese",
  "German",
  "French",
  "Russian",
  "Chinese",
  "Japanese",
  "Korean",
  "Arabic",
  "Serbian",
];

 const Register = () => {
   const navigate = useNavigate();
   const { signUp, user, loading: authLoading } = useAuth();
   const [step, setStep] = useState(1);
   const [isLoading, setIsLoading] = useState(false);
 
   // Redirect if already logged in
   useEffect(() => {
     if (user && !authLoading) {
       navigate("/");
     }
   }, [user, authLoading, navigate]);

  // Form state
  const [formData, setFormData] = useState({
    email: "",
    fullName: "",
    password: "",
    confirmPassword: "",
    age: "",
    region: "",
    languages: [] as string[],
    gamesPlayed: [] as string[],
    gamesLookingFor: [] as string[],
    discord: "",
    agreeTerms: false,
  });

  const updateFormData = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleArrayItem = (field: "languages" | "gamesPlayed" | "gamesLookingFor", item: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].includes(item)
        ? prev[field].filter((i) => i !== item)
        : [...prev[field], item],
    }));
  };

  const handleNext = () => {
    if (step === 1) {
      if (!formData.email || !formData.fullName || !formData.password || !formData.confirmPassword) {
        toast.error("Please fill in all fields");
        return;
      }
      if (formData.password !== formData.confirmPassword) {
        toast.error("Passwords do not match");
        return;
      }
      if (formData.password.length < 8) {
        toast.error("Password must be at least 8 characters");
        return;
      }
    }

    if (step === 2) {
      if (!formData.age || !formData.region || formData.languages.length === 0) {
        toast.error("Please fill in all fields");
        return;
      }
       const age = parseInt(formData.age);
       if (isNaN(age) || age < 13 || age > 120) {
         toast.error("Please enter a valid age (13-120)");
         return;
       }
    }

    setStep(step + 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.gamesPlayed.length === 0 || formData.gamesLookingFor.length === 0) {
      toast.error("Please select at least one game");
      return;
    }

    if (!formData.discord) {
      toast.error("Please enter your Discord username");
      return;
    }

    if (!formData.agreeTerms) {
      toast.error("Please agree to the terms of service");
      return;
    }

     setIsLoading(true);
 
     const { error } = await signUp(formData.email, formData.password, {
       full_name: formData.fullName,
       age: parseInt(formData.age),
       region: formData.region,
       languages: formData.languages,
       games_played: formData.gamesPlayed,
       games_looking_for: formData.gamesLookingFor,
       discord_username: formData.discord,
     });
 
     if (error) {
       if (error.message.includes("already registered")) {
         toast.error("This email is already registered. Please log in instead.");
       } else {
         toast.error(error.message);
       }
     } else {
       toast.success("Account created! Please check your email to verify your account.");
       navigate("/login");
     }
 
     setIsLoading(false);
  };

   if (authLoading) {
     return (
       <div className="min-h-screen flex items-center justify-center">
         <div className="animate-pulse text-muted-foreground">Loading...</div>
       </div>
     );
   }
 
   return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid-pattern opacity-20" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[128px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-[128px]" />

      <div className="relative w-full max-w-lg">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center glow-primary">
              <Gamepad2 className="w-7 h-7 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold text-foreground">
              Team<span className="text-primary">8</span>
            </span>
          </Link>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`w-12 h-1 rounded-full transition-colors ${
                s <= step ? "bg-primary" : "bg-secondary"
              }`}
            />
          ))}
        </div>

        {/* Registration Card */}
        <div className="bg-card border border-border rounded-2xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-foreground mb-2">
              {step === 1 && "Create your account"}
              {step === 2 && "Tell us about yourself"}
              {step === 3 && "Gaming preferences"}
            </h1>
            <p className="text-muted-foreground">
              {step === 1 && "Start finding your perfect teammates"}
              {step === 2 && "Help us match you with the right players"}
              {step === 3 && "What games are you playing?"}
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            {/* Step 1: Account Info */}
            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="email" className="text-foreground">
                    Email
                  </Label>
                  <div className="relative mt-2">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      className="pl-10 h-12 bg-secondary border-border"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="fullName" className="text-foreground">
                    Full Name
                  </Label>
                  <div className="relative mt-2">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="John Doe"
                      value={formData.fullName}
                      onChange={(e) => updateFormData("fullName", e.target.value)}
                      className="pl-10 h-12 bg-secondary border-border"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="password" className="text-foreground">
                    Password
                  </Label>
                  <div className="relative mt-2">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={(e) => updateFormData("password", e.target.value)}
                      className="pl-10 h-12 bg-secondary border-border"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="confirmPassword" className="text-foreground">
                    Confirm Password
                  </Label>
                  <div className="relative mt-2">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      value={formData.confirmPassword}
                      onChange={(e) => updateFormData("confirmPassword", e.target.value)}
                      className="pl-10 h-12 bg-secondary border-border"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Personal Info */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="age" className="text-foreground">
                    Age
                  </Label>
                  <div className="relative mt-2">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="age"
                      type="number"
                      placeholder="18"
                      min="13"
                      max="100"
                      value={formData.age}
                      onChange={(e) => updateFormData("age", e.target.value)}
                      className="pl-10 h-12 bg-secondary border-border"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-foreground">Region</Label>
                  <div className="relative mt-2">
                    <Select
                      value={formData.region}
                      onValueChange={(value) => updateFormData("region", value)}
                    >
                      <SelectTrigger className="h-12 bg-secondary border-border">
                        <Globe className="absolute left-3 w-5 h-5 text-muted-foreground" />
                        <SelectValue placeholder="Select your region" className="pl-8" />
                      </SelectTrigger>
                      <SelectContent>
                        {regions.map((region) => (
                          <SelectItem key={region} value={region}>
                            {region}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label className="text-foreground mb-3 block">Languages Spoken</Label>
                  <div className="flex flex-wrap gap-2">
                    {languages.map((lang) => (
                      <button
                        key={lang}
                        type="button"
                        onClick={() => toggleArrayItem("languages", lang)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          formData.languages.includes(lang)
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {lang}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Gaming Preferences */}
            {step === 3 && (
              <div className="space-y-6">
                <div>
                  <Label className="text-foreground mb-3 block">Games You Play</Label>
                  <div className="flex flex-wrap gap-2">
                    {games.map((game) => (
                      <button
                        key={game}
                        type="button"
                        onClick={() => toggleArrayItem("gamesPlayed", game)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          formData.gamesPlayed.includes(game)
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {game}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-foreground mb-3 block">Games Looking for Teammates In</Label>
                  <div className="flex flex-wrap gap-2">
                    {games.map((game) => (
                      <button
                        key={game}
                        type="button"
                        onClick={() => toggleArrayItem("gamesLookingFor", game)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          formData.gamesLookingFor.includes(game)
                            ? "bg-accent text-accent-foreground"
                            : "bg-secondary text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {game}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="discord" className="text-foreground">
                    Discord Username
                  </Label>
                  <div className="relative mt-2">
                    <MessageCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="discord"
                      type="text"
                      placeholder="username#1234"
                      value={formData.discord}
                      onChange={(e) => updateFormData("discord", e.target.value)}
                      className="pl-10 h-12 bg-secondary border-border"
                    />
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Checkbox
                    id="terms"
                    checked={formData.agreeTerms}
                    onCheckedChange={(checked) => updateFormData("agreeTerms", checked)}
                  />
                  <Label htmlFor="terms" className="text-sm text-muted-foreground leading-relaxed">
                    I agree to the{" "}
                    <a href="#" className="text-primary hover:underline">
                      Terms of Service
                    </a>{" "}
                    and{" "}
                    <a href="#" className="text-primary hover:underline">
                      Privacy Policy
                    </a>
                  </Label>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex gap-3 mt-8">
              {step > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  className="flex-1"
                  onClick={() => setStep(step - 1)}
                >
                  Back
                </Button>
              )}
              {step < 3 ? (
                <Button
                  type="button"
                  variant="hero"
                  size="lg"
                  className="flex-1"
                  onClick={handleNext}
                >
                  Continue
                  <ArrowRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  type="submit"
                  variant="hero"
                  size="lg"
                  className="flex-1"
                  disabled={isLoading}
                >
                  {isLoading ? "Creating account..." : "Create Account"}
                </Button>
              )}
            </div>
          </form>

          <div className="mt-8 text-center">
            <p className="text-muted-foreground">
              Already have an account?{" "}
              <Link to="/login" className="text-primary hover:underline font-medium">
                Log in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
