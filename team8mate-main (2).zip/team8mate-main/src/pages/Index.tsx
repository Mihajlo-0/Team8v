import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import FeatureCard from "@/components/ui/FeatureCard";
import GameCard from "@/components/ui/GameCard";
import PricingCard from "@/components/ui/PricingCard";
import { Users, Globe, Zap, Shield, MessageCircle, Target, ArrowRight, Frown, Clock, Volume2, Gamepad2, Search } from "lucide-react";

import valorantImg from "@/assets/games/valorant.jpg";
import cs2Img from "@/assets/games/cs2.jpg";
import lolImg from "@/assets/games/lol.jpg";
import fortniteImg from "@/assets/games/fortnite.jpg";
import apexImg from "@/assets/games/apex.jpg";
import overwatchImg from "@/assets/games/overwatch.jpg";

const games = [
  { name: "Valorant", image: valorantImg, players: "2.4k+" },
  { name: "CS2", image: cs2Img, players: "1.8k+" },
  { name: "League of Legends", image: lolImg, players: "3.2k+" },
  { name: "Fortnite", image: fortniteImg, players: "1.5k+" },
  { name: "Apex Legends", image: apexImg, players: "980+" },
  { name: "Overwatch 2", image: overwatchImg, players: "1.1k+" },
];

const features = [
  {
    icon: Target,
    title: "Smart Matching",
    description: "Our algorithm finds players who match your games, region, language, and playstyle preferences.",
  },
  {
    icon: Globe,
    title: "Global Community",
    description: "Connect with gamers from around the world. Filter by region to find teammates in your timezone.",
  },
  {
    icon: Zap,
    title: "Instant Connect",
    description: "No waiting. Find compatible teammates in seconds and start playing together right away.",
  },
  {
    icon: Shield,
    title: "Safe & Verified",
    description: "All players are verified. Report toxic behavior and keep the community friendly.",
  },
  {
    icon: MessageCircle,
    title: "Built-in Chat",
    description: "Chat directly within Team8. No need to share personal contact info until you're ready.",
  },
  {
    icon: Users,
    title: "Team Builder",
    description: "Looking for a full squad? Build your dream team with multiple compatible players.",
  },
];

const problems = [
  { icon: Clock, text: "Wasting time with random matchmaking" },
  { icon: Volume2, text: "Toxic players ruining your games" },
  { icon: Globe, text: "Wrong regions and high ping" },
  { icon: Frown, text: "Language barriers with teammates" },
];

const Index = () => {
  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-grid-pattern opacity-20" />
        <div className="absolute inset-0 bg-gradient-radial" />
        <div className="absolute top-1/3 left-1/4 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[160px] animate-pulse-glow" />
        <div className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] bg-accent/10 rounded-full blur-[160px] animate-pulse-glow" style={{ animationDelay: '1.5s' }} />

        {/* Decorative gaming icons */}
        <div className="absolute top-20 left-[10%] opacity-[0.04]">
          <Gamepad2 className="w-40 h-40 animate-float" />
        </div>
        <div className="absolute bottom-32 right-[8%] opacity-[0.04]">
          <Target className="w-32 h-32 animate-float" style={{ animationDelay: '2s' }} />
        </div>
        <div className="absolute top-40 right-[15%] opacity-[0.03]">
          <Shield className="w-24 h-24 animate-float" style={{ animationDelay: '3s' }} />
        </div>

        <div className="container relative z-10 px-4 py-24">
          <div className="max-w-4xl mx-auto text-center stagger-children">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-primary/8 border border-primary/15 rounded-full px-5 py-2.5 mb-10">
              <span className="online-dot w-2 h-2" />
              <span className="text-sm text-primary font-medium">Now connecting 10,000+ gamers</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-foreground leading-[1.1] mb-8 tracking-tight">
              Find the perfect teammate
              <span className="block text-gradient mt-2">for your next match.</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed">
              Stop wasting hours searching for reliable teammates. Team8 helps you instantly find players who match your games, region, language and playstyle.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/find-teammate">
                <Button variant="hero" size="xl" className="w-full sm:w-auto">
                  <Search className="w-5 h-5" />
                  Find Teammates
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="hero-outline" size="xl" className="w-full sm:w-auto">
                  Create Account
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-12 mt-20">
              {[
                { value: "10K+", label: "Active Gamers" },
                { value: "50+", label: "Games Supported" },
                { value: "150+", label: "Countries" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl font-extrabold text-foreground">{stat.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-24 bg-card/50">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-14">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Tired of Bad Teammates?
              </h2>
              <p className="text-muted-foreground text-lg max-w-xl mx-auto">
                We know how frustrating it is. Random matchmaking wastes your time and ruins your games.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {problems.map((problem, index) => (
                <div
                  key={index}
                  className="flex items-center gap-4 bg-destructive/5 border border-destructive/10 rounded-2xl p-6 transition-all duration-200 hover:bg-destructive/8"
                >
                  <div className="w-11 h-11 rounded-xl bg-destructive/10 flex items-center justify-center flex-shrink-0">
                    <problem.icon className="w-5 h-5 text-destructive" />
                  </div>
                  <span className="text-foreground font-medium">{problem.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solution / Features Section */}
      <section className="py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Team8 Has Your Back
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              We match you with players who actually fit. Same games, same region, same language, same goals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* Games Section */}
      <section className="py-24 bg-card/50">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Popular Games
            </h2>
            <p className="text-muted-foreground text-lg">
              Find teammates for your favorite competitive games
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-5 max-w-6xl mx-auto">
            {games.map((game, index) => (
              <GameCard key={index} {...game} />
            ))}
          </div>

          <div className="text-center mt-14">
            <Link to="/find-teammate">
              <Button variant="outline" size="lg">
                View All Games
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Simple, Fair Pricing
            </h2>
            <p className="text-muted-foreground text-lg">
              Start for free. Upgrade when you need more connections.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard
              name="Free"
              price="Free"
              description="Perfect for casual gamers"
              features={[
                "2 contacts per day",
                "Basic search filters",
                "View player profiles",
                "In-app chat",
              ]}
              buttonText="Get Started"
            />
            <PricingCard
              name="Gamer"
              price="$4.99"
              description="For dedicated players"
              features={[
                "5 contacts per day",
                "Advanced search filters",
                "Priority matching",
                "In-app chat",
                "Badge on profile",
              ]}
              popular
              buttonText="Upgrade Now"
            />
            <PricingCard
              name="Pro"
              price="$9.99"
              description="For serious competitors"
              features={[
                "Unlimited contacts",
                "All search filters",
                "Priority matching",
                "In-app chat",
                "Pro badge on profile",
                "Team builder access",
              ]}
              buttonText="Go Pro"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-card/50">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              Ready to Find Your Squad?
            </h2>
            <p className="text-muted-foreground text-lg mb-10">
              Join thousands of gamers who've already found their perfect teammates on Team8.
            </p>
            <Link to="/register">
              <Button variant="hero" size="xl">
                Create Free Account
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
