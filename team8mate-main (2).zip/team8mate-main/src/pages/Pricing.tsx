import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import PricingCard from "@/components/ui/PricingCard";
import { ArrowRight, Check, HelpCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const pricingPlans = [
  {
    name: "Free",
    price: "Free",
    description: "Perfect for casual gamers",
    features: [
      "2 contacts per day",
      "Basic search filters",
      "View player profiles",
      "In-app chat",
      "Community access",
    ],
    buttonText: "Get Started",
  },
  {
    name: "Gamer",
    price: "$4.99",
    description: "For dedicated players",
    features: [
      "5 contacts per day",
      "Advanced search filters",
      "Priority matching",
      "In-app chat",
      "Gamer badge on profile",
      "Priority support",
    ],
    popular: true,
    buttonText: "Upgrade Now",
  },
  {
    name: "Pro",
    price: "$9.99",
    description: "For serious competitors",
    features: [
      "Unlimited contacts",
      "All search filters",
      "Priority matching",
      "In-app chat",
      "Pro badge on profile",
      "Team builder access",
      "Priority support",
      "Early access to features",
    ],
    buttonText: "Go Pro",
  },
];

const faqs = [
  {
    question: "How does the contact limit work?",
    answer: "Each day, you can reach out to a limited number of new players based on your plan. Free users get 2 contacts per day, Gamer plan gets 5, and Pro plan has unlimited contacts. Your limit resets every 24 hours.",
  },
  {
    question: "Can I cancel my subscription anytime?",
    answer: "Yes! You can cancel your subscription at any time. You'll continue to have access to your paid features until the end of your billing period.",
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards (Visa, Mastercard, American Express) and PayPal. All payments are processed securely.",
  },
  {
    question: "Is there a refund policy?",
    answer: "If you're not satisfied with your purchase, contact us within 7 days for a full refund. No questions asked.",
  },
  {
    question: "What's included in the Team Builder feature?",
    answer: "Team Builder (Pro plan) lets you create and manage teams, invite multiple players at once, and set up group chats. Perfect for forming competitive squads.",
  },
];

const Pricing = () => {
  return (
    <div className="min-h-screen py-16">
      <div className="container relative px-4">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-5 tracking-tight">
            Simple, Fair Pricing
          </h1>
          <p className="text-lg text-muted-foreground">
            Start for free. Upgrade when you need more connections.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-24">
          {pricingPlans.map((plan, index) => (
            <PricingCard key={index} {...plan} />
          ))}
        </div>

        {/* Feature Comparison */}
        <div className="max-w-4xl mx-auto mb-24">
          <h2 className="text-2xl font-bold text-foreground text-center mb-10">
            Compare Plans
          </h2>
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="grid grid-cols-4 gap-4 p-5 border-b border-border bg-secondary/30">
              <div className="font-semibold text-foreground text-sm">Feature</div>
              <div className="font-semibold text-foreground text-center text-sm">Free</div>
              <div className="font-semibold text-primary text-center text-sm">Gamer</div>
              <div className="font-semibold text-foreground text-center text-sm">Pro</div>
            </div>
            {[
              { feature: "Daily contacts", free: "2", gamer: "5", pro: "Unlimited" },
              { feature: "Search filters", free: "Basic", gamer: "Advanced", pro: "All" },
              { feature: "In-app chat", free: true, gamer: true, pro: true },
              { feature: "Profile badge", free: false, gamer: true, pro: true },
              { feature: "Priority matching", free: false, gamer: true, pro: true },
              { feature: "Team builder", free: false, gamer: false, pro: true },
              { feature: "Priority support", free: false, gamer: true, pro: true },
            ].map((row, index) => (
              <div
                key={index}
                className="grid grid-cols-4 gap-4 p-5 border-b border-border last:border-0"
              >
                <div className="text-muted-foreground text-sm">{row.feature}</div>
                {["free", "gamer", "pro"].map((plan) => {
                  const val = row[plan as keyof typeof row];
                  return (
                    <div key={plan} className="text-center">
                      {typeof val === "boolean" ? (
                        val ? (
                          <Check className="w-4 h-4 text-primary mx-auto" />
                        ) : (
                          <span className="text-muted-foreground text-sm">—</span>
                        )
                      ) : (
                        <span className={`text-sm ${plan === "gamer" ? "text-primary font-medium" : "text-foreground"}`}>
                          {val}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto mb-24">
          <h2 className="text-2xl font-bold text-foreground text-center mb-10">
            Frequently Asked Questions
          </h2>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card border border-border rounded-2xl px-6"
              >
                <AccordionTrigger className="text-foreground hover:text-primary text-sm">
                  <span className="flex items-center gap-3">
                    <HelpCircle className="w-4 h-4 text-primary flex-shrink-0" />
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-6 text-sm">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* CTA */}
        <div className="max-w-3xl mx-auto text-center">
          <div className="bg-card border border-border rounded-2xl p-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Ready to Find Your Squad?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Join thousands of gamers who've already found their perfect teammates.
            </p>
            <Link to="/register">
              <Button variant="hero" size="xl">
                Get Started for Free
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
