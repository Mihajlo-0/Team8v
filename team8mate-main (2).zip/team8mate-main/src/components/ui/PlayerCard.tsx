import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Globe, Calendar, MessageCircle, Gamepad2 } from "lucide-react";

interface PlayerCardProps {
  name: string;
  games: string[];
  region: string;
  languages: string[];
  age: number;
  avatar?: string;
  rank?: string;
  online?: boolean;
  onContact?: () => void;
  disabled?: boolean;
}

const PlayerCard = ({
  name,
  games,
  region,
  languages,
  age,
  avatar,
  rank,
  online = false,
  onContact,
  disabled = false,
}: PlayerCardProps) => {
  return (
    <div className="bg-card border border-border rounded-2xl p-6 card-hover animate-slide-up">
      <div className="flex items-start gap-4">
        {/* Avatar */}
        <div className="relative flex-shrink-0">
          <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
            {avatar ? (
              <img src={avatar} alt={name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-xl font-bold text-primary">
                {name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
          {online && (
            <div className="absolute -bottom-0.5 -right-0.5 online-dot border-2 border-card" />
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-foreground truncate">{name}</h3>
            {rank && (
              <Badge variant="secondary" className="bg-accent/10 text-accent border-0 text-xs font-semibold">
                {rank}
              </Badge>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {region}
            </span>
            <span className="flex items-center gap-1">
              <Globe className="w-3.5 h-3.5" />
              {languages.join(", ")}
            </span>
            {age > 0 && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {age}y
              </span>
            )}
          </div>

          {/* Games */}
          <div className="flex flex-wrap gap-1.5 mt-3">
            {games.map((game) => (
              <Badge key={game} variant="secondary" className="bg-primary/8 text-primary border-0 text-xs">
                <Gamepad2 className="w-3 h-3 mr-1" />
                {game}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Button */}
      <div className="mt-5 pt-4 border-t border-border">
        <Button
          onClick={onContact}
          disabled={disabled}
          className="w-full"
          variant={disabled ? "outline" : "default"}
          size="sm"
        >
          <MessageCircle className="w-4 h-4" />
          {disabled ? "Login to Message" : "Message"}
        </Button>
      </div>
    </div>
  );
};

export default PlayerCard;
