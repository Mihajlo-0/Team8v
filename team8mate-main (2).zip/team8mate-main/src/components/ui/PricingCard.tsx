import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

interface PricingCardProps {
  name: string;
  price: string;
  period?: string;
  description: string;
  features: string[];
  popular?: boolean;
  buttonText: string;
  onSelect?: () => void;
}

const PricingCard = ({
  name,
  price,
  period = "/month",
  description,
  features,
  popular = false,
  buttonText,
  onSelect,
}: PricingCardProps) => {
  return (
    <div
      className={`relative bg-card border rounded-2xl p-8 card-hover ${
        popular ? "border-primary/40 glow-primary" : "border-border"
      }`}
    >
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="bg-primary text-primary-foreground text-xs font-bold px-4 py-1.5 rounded-full">
            Most Popular
          </span>
        </div>
      )}

      <div className="text-center mb-8">
        <h3 className="font-bold text-lg text-foreground mb-1">{name}</h3>
        <p className="text-muted-foreground text-sm">{description}</p>
      </div>

      <div className="text-center mb-8">
        <span className="text-4xl font-extrabold text-foreground">{price}</span>
        {price !== "Free" && (
          <span className="text-muted-foreground text-sm">{period}</span>
        )}
      </div>

      <ul className="space-y-3.5 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center gap-3 text-sm">
            <div className="w-5 h-5 rounded-full bg-primary/8 flex items-center justify-center flex-shrink-0">
              <Check className="w-3 h-3 text-primary" />
            </div>
            <span className="text-foreground">{feature}</span>
          </li>
        ))}
      </ul>

      <Button
        onClick={onSelect}
        variant={popular ? "hero" : "outline"}
        className="w-full"
        size="lg"
      >
        {buttonText}
      </Button>
    </div>
  );
};

export default PricingCard;
