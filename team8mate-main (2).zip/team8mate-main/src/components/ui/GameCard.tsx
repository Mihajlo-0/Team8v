interface GameCardProps {
  name: string;
  image: string;
  players?: string;
}

const GameCard = ({ name, image, players }: GameCardProps) => {
  return (
    <div className="group relative overflow-hidden rounded-2xl card-hover cursor-pointer">
      <div className="aspect-[3/4] relative">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="font-bold text-foreground text-sm">{name}</h3>
          {players && (
            <p className="text-primary text-xs font-medium mt-0.5">{players} players</p>
          )}
        </div>
      </div>
      <div className="absolute inset-0 border-2 border-transparent group-hover:border-primary/30 rounded-2xl transition-all duration-300" />
    </div>
  );
};

export default GameCard;
