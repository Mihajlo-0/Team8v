
-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Users can view basic profiles for search" ON public.profiles;

-- Replace with authenticated-only policy
CREATE POLICY "Users can view basic profiles for search"
  ON public.profiles FOR SELECT
  USING (auth.uid() IS NOT NULL);
