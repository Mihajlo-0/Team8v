-- ============================================
-- Team8 Database Schema
-- ============================================

-- 1. Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  age INTEGER CHECK (age >= 13 AND age <= 120),
  region TEXT NOT NULL,
  languages TEXT[] NOT NULL DEFAULT '{}',
  games_played TEXT[] NOT NULL DEFAULT '{}',
  games_looking_for TEXT[] NOT NULL DEFAULT '{}',
  discord_username TEXT,
  skill_level TEXT DEFAULT 'casual',
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 2. Create subscription_plans table (static lookup)
CREATE TABLE public.subscription_plans (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  max_contacts_per_day INTEGER NOT NULL,
  price_monthly DECIMAL(10,2) NOT NULL DEFAULT 0,
  features JSONB NOT NULL DEFAULT '[]'
);

-- Insert default plans
INSERT INTO public.subscription_plans (name, max_contacts_per_day, price_monthly, features) VALUES
  ('free', 2, 0, '["Basic search filters", "View player profiles", "In-app chat"]'),
  ('gamer', 5, 4.99, '["Advanced search filters", "Priority matching", "Gamer badge"]'),
  ('pro', -1, 9.99, '["Unlimited contacts", "Team builder", "Pro badge", "Priority support"]');

-- Enable RLS (public read)
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view subscription plans"
  ON public.subscription_plans FOR SELECT
  USING (true);

-- 3. Create user_subscriptions table
CREATE TABLE public.user_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  plan_id INTEGER NOT NULL REFERENCES public.subscription_plans(id) DEFAULT 1,
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  end_date DATE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, is_active) -- Only one active subscription per user
);

ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

-- 4. Create contacts table (accepted connections)
CREATE TABLE public.contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  contact_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, contact_id),
  CHECK (user_id != contact_id)
);

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

-- 5. Create contact_requests table
CREATE TABLE public.contact_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  requested_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (requester_id != requested_id)
);

ALTER TABLE public.contact_requests ENABLE ROW LEVEL SECURITY;

-- 6. Create daily_contact_count for tracking
CREATE TABLE public.daily_contact_counts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  contact_date DATE NOT NULL DEFAULT CURRENT_DATE,
  count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, contact_date)
);

ALTER TABLE public.daily_contact_counts ENABLE ROW LEVEL SECURITY;

-- 7. Create chats table
CREATE TABLE public.chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user1_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  user2_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (user1_id < user2_id) -- Ensure consistent ordering to prevent duplicates
);

ALTER TABLE public.chats ENABLE ROW LEVEL SECURITY;

-- Create unique index for chat pairs
CREATE UNIQUE INDEX idx_chats_user_pair ON public.chats(user1_id, user2_id);

-- 8. Create messages table
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID NOT NULL REFERENCES public.chats(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- ============================================
-- Helper Functions
-- ============================================

-- Check if two users are connected
CREATE OR REPLACE FUNCTION public.is_connected(user_a UUID, user_b UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.contacts
    WHERE (user_id = user_a AND contact_id = user_b)
       OR (user_id = user_b AND contact_id = user_a)
  );
$$;

-- Get user's current plan max contacts (-1 = unlimited)
CREATE OR REPLACE FUNCTION public.get_user_plan_max_contacts(p_user_id UUID)
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT sp.max_contacts_per_day
     FROM public.user_subscriptions us
     JOIN public.subscription_plans sp ON us.plan_id = sp.id
     WHERE us.user_id = p_user_id
       AND us.is_active = true
     LIMIT 1),
    2 -- Default to free plan limit
  );
$$;

-- Get user's daily sent contact requests count
CREATE OR REPLACE FUNCTION public.get_daily_sent_contacts(p_user_id UUID)
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT count FROM public.daily_contact_counts
     WHERE user_id = p_user_id
       AND contact_date = CURRENT_DATE),
    0
  );
$$;

-- Check if user can send contact request
CREATE OR REPLACE FUNCTION public.can_send_contact_request(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    CASE 
      WHEN public.get_user_plan_max_contacts(p_user_id) = -1 THEN true -- Unlimited
      ELSE public.get_daily_sent_contacts(p_user_id) < public.get_user_plan_max_contacts(p_user_id)
    END;
$$;

-- ============================================
-- RLS Policies
-- ============================================

-- Profiles policies
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  USING (id = auth.uid());

CREATE POLICY "Users can view connected profiles"
  ON public.profiles FOR SELECT
  USING (public.is_connected(id, auth.uid()));

CREATE POLICY "Users can view basic profiles for search"
  ON public.profiles FOR SELECT
  USING (true); -- Allow viewing for search, but sensitive data protected at app level

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (id = auth.uid());

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (id = auth.uid());

-- User subscriptions policies
CREATE POLICY "Users can view own subscription"
  ON public.user_subscriptions FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own subscription"
  ON public.user_subscriptions FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own subscription"
  ON public.user_subscriptions FOR UPDATE
  USING (user_id = auth.uid());

-- Contacts policies
CREATE POLICY "Users can view own contacts"
  ON public.contacts FOR SELECT
  USING (user_id = auth.uid() OR contact_id = auth.uid());

CREATE POLICY "Users can insert contacts"
  ON public.contacts FOR INSERT
  WITH CHECK (user_id = auth.uid() OR contact_id = auth.uid());

CREATE POLICY "Users can delete own contacts"
  ON public.contacts FOR DELETE
  USING (user_id = auth.uid() OR contact_id = auth.uid());

-- Contact requests policies
CREATE POLICY "Users can view own requests"
  ON public.contact_requests FOR SELECT
  USING (requester_id = auth.uid() OR requested_id = auth.uid());

CREATE POLICY "Users can create contact requests"
  ON public.contact_requests FOR INSERT
  WITH CHECK (requester_id = auth.uid());

CREATE POLICY "Users can update own requests"
  ON public.contact_requests FOR UPDATE
  USING (requester_id = auth.uid() OR requested_id = auth.uid());

-- Daily contact counts policies
CREATE POLICY "Users can view own contact counts"
  ON public.daily_contact_counts FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own contact counts"
  ON public.daily_contact_counts FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own contact counts"
  ON public.daily_contact_counts FOR UPDATE
  USING (user_id = auth.uid());

-- Chats policies
CREATE POLICY "Users can view own chats"
  ON public.chats FOR SELECT
  USING (user1_id = auth.uid() OR user2_id = auth.uid());

CREATE POLICY "Users can create chats"
  ON public.chats FOR INSERT
  WITH CHECK (user1_id = auth.uid() OR user2_id = auth.uid());

-- Messages policies
CREATE POLICY "Users can view messages in their chats"
  ON public.messages FOR SELECT
  USING (
    chat_id IN (
      SELECT id FROM public.chats 
      WHERE user1_id = auth.uid() OR user2_id = auth.uid()
    )
  );

CREATE POLICY "Users can send messages in their chats"
  ON public.messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid() AND
    chat_id IN (
      SELECT id FROM public.chats 
      WHERE user1_id = auth.uid() OR user2_id = auth.uid()
    )
  );

-- ============================================
-- Triggers for updated_at
-- ============================================

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_subscriptions_updated_at
  BEFORE UPDATE ON public.user_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_contact_requests_updated_at
  BEFORE UPDATE ON public.contact_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_chats_updated_at
  BEFORE UPDATE ON public.chats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- Trigger to create profile on user signup
-- ============================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, region, languages, games_played, games_looking_for)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    COALESCE(NEW.raw_user_meta_data->>'region', 'Not specified'),
    COALESCE(ARRAY(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'languages')), ARRAY['English']::TEXT[]),
    COALESCE(ARRAY(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'games_played')), ARRAY[]::TEXT[]),
    COALESCE(ARRAY(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'games_looking_for')), ARRAY[]::TEXT[])
  );
  
  -- Create default free subscription
  INSERT INTO public.user_subscriptions (user_id, plan_id)
  VALUES (NEW.id, 1);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();